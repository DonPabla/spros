import React from 'react';

function aboutUs(props) {
    return (
        <div>
            dsadsa
        </div>
    );
}

export default aboutUs;